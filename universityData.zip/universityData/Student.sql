﻿CREATE TABLE [dbo].[Student]
(

/*REQUIRED fields here: */
	[StudentID] INT IDENTITY (1,1) NOT NULL,
    [Lastname] NVARCHAR (50) NOT NULL,
    [Firstname] NVARCHAR (50) NOT NULL,
    [Middlename] NVARCHAR (50) NULL,
    [CurrentGPA] DECIMAL (3,2) NOT NULL,

    /*HOW TO SET LENGTH FOR SSN, SAT SCORES ?? */
    [StudentSSN] INT NOT NULL,

    [DateOfBirth] DATE NOT NULL,
    [GraduationDate] DATE NOT NULL,
    [StudentEmail] NVARCHAR (50) NOT NULL,
    
    [SATmath] INT NOT NULL,
    [SATverbal] INT NOT NULL,

    /*
    COMBINED SAT score to be calculated in the Application object ??
    */

    [Gender] NVARCHAR(10) NULL,

    /* I don't know what format to put for phone numbers, in case they do with spaces or dashes */
    [HomePhone] NVARCHAR (14) NULL,
    [CellPhone] NVARCHAR (14) NULL,

/*FOREIGN KEYS HERE: These are tables that Students will also connect to. NULL because they are not required RED fields */
    [HighSchoolID] INT NULL,
    [AddressID] INT NULL,
    [MajorID] INT NULL
)

/*

EXAMPLE:


CREATE TABLE [dbo].[Student] (
    [StudentID]      INT           IDENTITY (1, 1) NOT NULL,
    [LastName]       NVARCHAR (50) NULL,
    [FirstName]      NVARCHAR (50) NULL,
    [EnrollmentDate] DATETIME      NULL,
    PRIMARY KEY CLUSTERED ([StudentID] ASC)
)
*/



/*

student id
first name
last name
middle name
GPA
combinedSATscore
SATmath
SATverbal
submission date
enrollment year
enrollment semester


SSN **must be unique**
email
homePhone
cellPhone
DateOfBirth
Gender



street
city
state
ZIPcode

highschoolName
highschoolCity

graduation date


*/