﻿CREATE TABLE [dbo].[Address]
(
	[AddressID] INT IDENTITY (1,1) NOT NULL,
	[Street] NVARCHAR (50) NOT NULL,
	[City] NVARCHAR (50) NOT NULL,
	[State] NVARCHAR (15) NOT NULL,
	[ZIPcode] INT NOT NULL

)


/*should we just put all these variables, except addressID, into the Student table, and delete this one? */
