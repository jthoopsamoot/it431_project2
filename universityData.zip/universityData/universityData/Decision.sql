﻿CREATE TABLE [dbo].[Decision]
(
[DecisionID] INT IDENTITY (1,1) NOT NULL,
    [DecisionName] NVARCHAR (50) NOT NULL,
 

	PRIMARY KEY CLUSTERED ([DecisionID] ASC)
)

