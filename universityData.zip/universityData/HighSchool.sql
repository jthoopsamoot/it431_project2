﻿CREATE TABLE [dbo].[HighSchool]
(
	[HighSchoolID] INT IDENTITY (1,1) NOT NULL,
	[HighSchoolName] NVARCHAR (50) NOT NULL,
	[HighSchoolCity] NVARCHAR (50) NOT NULL
)


/*should we just put HighSchoolName and HighSchoolCity in the Student table, and delete this one? */