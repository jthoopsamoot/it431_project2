﻿CREATE TABLE [dbo].[Student]
(

/*REQUIRED fields here: */
	[StudentSSN] INT IDENTITY (1,1) NOT NULL,
    [Lastname] NVARCHAR (50) NOT NULL,
    [Firstname] NVARCHAR (50) NOT NULL,
    [Middlename] NVARCHAR (50) NULL,
    [CurrentGPA] DECIMAL (3,2) NOT NULL,

   /*HOW TO SET LENGTH FOR SSN, SAT SCORES ?? */
    [DateOfBirth] DATE NOT NULL,
    [GraduationDate] DATE NOT NULL,
    [StudentEmail] NVARCHAR (50) NOT NULL,

/* Address information */
	[Street] NVARCHAR (50) NOT NULL,
	[City] NVARCHAR (50) NOT NULL,
	[State] NVARCHAR (15) NOT NULL,
	[ZIPcode] INT NOT NULL,

/* High school */
	[HighSchoolName] NVARCHAR (50) NOT NULL,
	[HighSchoolCity] NVARCHAR (50) NOT NULL,    

    [SATmath] INT NOT NULL,
    [SATverbal] INT NOT NULL,

    /*
    COMBINED SAT score to be calculated in the Application object ??
    */
    [Gender] NVARCHAR(10) NULL,

    /* I don't know what format to put for phone numbers, in case they do with spaces or dashes */
    [HomePhone] NVARCHAR (14) NULL,
    [CellPhone] NVARCHAR (14) NULL,

	PRIMARY KEY CLUSTERED ([StudentSSN] ASC)
)