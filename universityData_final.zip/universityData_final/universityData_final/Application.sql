﻿CREATE TABLE [dbo].[Application]
(
	[ApplicationID] INT IDENTITY (1,1) NOT NULL,
    [MajorID] INT NOT NULL,
    [StudentSSN] INT NOT NULL,
    [DecisionID] INT NOT NULL,
   [EnrollmentID] INT NOT NULL,
    [SubmissionDate] NVARCHAR (50) NULL
   

 CONSTRAINT [FK_dbo.Application_dbo.Major_MajorID] FOREIGN KEY ([MajorID]) 
        REFERENCES [dbo].[Major] ([MajorID]) ON DELETE CASCADE,

    CONSTRAINT [FK_dbo.Application_dbo.Student_StudentSSN] FOREIGN KEY ([StudentSSN]) 
        REFERENCES [dbo].[Student] ([StudentSSN]) ON DELETE CASCADE,

     CONSTRAINT [FK_dbo.Application_dbo.Decision_DecisionID] FOREIGN KEY ([DecisionID]) 
        REFERENCES [dbo].[Decision] ([DecisionID]) ON DELETE CASCADE,

     CONSTRAINT [FK_dbo.Application_dbo.Enrollment_EnrollmentID] FOREIGN KEY ([EnrollmentID]) 
        REFERENCES [dbo].[Enrollment] ([EnrollmentID]) ON DELETE CASCADE
)
