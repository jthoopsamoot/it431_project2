﻿CREATE TABLE [dbo].[Major]
(
	[MajorID] INT IDENTITY (1,1) NOT NULL,
    [MajorName] NVARCHAR (50) NOT NULL,
    [MajorSchool] NVARCHAR(50) NULL

	PRIMARY KEY CLUSTERED ([MajorID] ASC)
)