﻿CREATE TABLE [dbo].[Enrollment]
(
	[EnrollmentID] INT IDENTITY (1,1) NOT NULL,
    [EnrollmentName] NVARCHAR (50) NOT NULL,
    [EnrollmentYear] INT NOT NULL

	PRIMARY KEY CLUSTERED ([EnrollmentID] ASC)
)
